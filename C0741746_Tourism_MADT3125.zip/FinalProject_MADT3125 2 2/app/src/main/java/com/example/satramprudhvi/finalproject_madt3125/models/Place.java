package com.example.satramprudhvi.finalproject_madt3125.models;

import android.content.Context;

import com.example.satramprudhvi.finalproject_madt3125.R;

import java.util.ArrayList;

public class Place {

    // Store the id of the  movie poster
    private int mImageDrawable;
    // Store the name of the movie
    private String mName;
    // Store the release date of the movie
    //private String mRelease;
    // Constructor that is used to create an instance of the Movie object
    public Place(int mImageDrawable, String mName) {
        this.mImageDrawable = mImageDrawable;
        this.mName = mName;
        //this.mRelease = mRelease;
    }

    public int getmImageDrawable() {
        return mImageDrawable;
    }

    public void setmImageDrawable(int mImageDrawable) {
        this.mImageDrawable = mImageDrawable;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public static ArrayList<Place> getPlaces() {
        ArrayList<Place> placeslist = new ArrayList<>();
        placeslist.add(new Place(R.drawable.zoo, "The Toronto Zoo" ));
        placeslist.add(new Place(R.drawable.casloma, "Casa Loma (Spanish for Hill House) "));
        placeslist.add(new Place(R.drawable.artgallery, "The Art Gallery" ));
        placeslist.add(new Place(R.drawable.cntower, "The CN Tower" ));
        placeslist.add(new Place(R.drawable.eaton, "The Toronto Eaton Centre"));
        placeslist.add(new Place(R.drawable.glacier, "Glacier National Park " ));
        placeslist.add(new Place(R.drawable.banff, "Banff National Park" ));
        placeslist.add(new Place(R.drawable.cityhall, "Toronto City Hall"));
        placeslist.add(new Place(R.drawable.stc, "Scarborough Town Center" ));
        placeslist.add(new Place(R.drawable.rogers, "Rogers Centre" ));
        placeslist.add(new Place(R.drawable.moraine, "moraine lake"));
        placeslist.add(new Place(R.drawable.musem, "Royal Ontario Museum" ));
        placeslist.add(new Place(R.drawable.niagra, "Niagara Falls" ));
        return placeslist;
    }

//    public String getmRelease() {
//        return mRelease;
//    }
//
//    public void setmRelease(String mRelease) {
//        this.mRelease = mRelease;
//    }

}
