package com.example.satramprudhvi.finalproject_madt3125.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.satramprudhvi.finalproject_madt3125.R;
import com.example.satramprudhvi.finalproject_madt3125.models.Place;

import java.util.List;

public class PlacesAdapter extends ArrayAdapter<Place>
    {
        private List<Place> placesArrayList;
        private Context mContext;

        public PlacesAdapter(Context context, List<Place> placelist)
        {
            super(context, 0, placelist);
            this.placesArrayList = placelist;
            this.mContext = context;

        }

        @Override
        public int getCount()
        {
            return placesArrayList.size();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {

            PlaceViewHolder mHolder;

            if(convertView == null)
            {
                convertView = LayoutInflater.from(mContext)
                        .inflate(R.layout.itemlistview,
                                parent,
                                false);
                mHolder = new PlaceViewHolder(convertView);
                convertView.setTag(mHolder);
            }
            else
            {
                mHolder = (PlaceViewHolder) convertView.getTag();
            }

            Place currentplace = placesArrayList.get(position);

            mHolder.image.setImageResource(currentplace.getmImageDrawable());
           mHolder.name.setText(currentplace.getmName());
            //mHolder.release.setText(currentplace.getmRelease());

            return convertView;
        }

        private class PlaceViewHolder
        {
            ImageView image;
            TextView name;
            //TextView release;

            public PlaceViewHolder(View view)
            {
                image = (ImageView)view.findViewById(R.id.imgplacehere);
                name = (TextView) view.findViewById(R.id.title1);
               // release = (TextView) view.findViewById(R.id.textView_release);
            }
        }
    }




