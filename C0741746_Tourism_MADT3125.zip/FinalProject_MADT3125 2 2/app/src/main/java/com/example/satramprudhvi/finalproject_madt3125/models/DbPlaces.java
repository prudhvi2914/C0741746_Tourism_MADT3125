package com.example.satramprudhvi.finalproject_madt3125.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.satramprudhvi.finalproject_madt3125.DBHelper;
import com.example.satramprudhvi.finalproject_madt3125.R;

import java.util.ArrayList;

public class DbPlaces {

    private static final String TABLE_NAME = "Places";
    private static final String KEY_IMG = "mImageDrawable";
    private static final String KEY_NAME = "mName";

    private DBHelper dbHelper;

    public DbPlaces(Context context) {
        this.dbHelper = new DBHelper(context);
    }

    public void insert(Place place) {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_IMG, place.getmImageDrawable());
        contentValues.put(KEY_NAME, place.getmName());
        database.insert(TABLE_NAME, null, contentValues);
        database.close();
    }
}
