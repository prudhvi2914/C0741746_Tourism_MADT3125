package com.example.satramprudhvi.finalproject_madt3125.detailslistactivity;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.satramprudhvi.finalproject_madt3125.R;

public class Zoo extends AppCompatActivity {
private ImageView imageView;
 TextView textView;
private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zoo);
        imageView = findViewById(R.id.stc);
        button = (Button) findViewById(R.id.getbanff);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Uri location = Uri.parse("geo:0,0?q=1600+Amphitheatre+Parkway,+Mountain+View,+California");
//                Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);

//
//                Uri uri = Uri.parse("geo:40.763500,-73.979305");
//                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
//                startActivity(intent);
//             //   startActivity(intent);
                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("http://maps.google.com/maps?saddr=20.344,34.34&daddr=20.5666,45.345"));
                startActivity(intent);
                //btn_click.setOnClickListener(new View.OnClickListener() {
                //    @Override
                //    public void onClick(View v) {
                //        new Handler().postDelayed(new Runnable() {
                //            @Override
                //            public void run() {
                //                Uri gmmIntentUri = Uri.parse("geo:0,0?q=");
                //                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                //                mapIntent.setPackage("com.google.android.apps.maps");
                //                startActivity(mapIntent);
                //            }
                //        }, 1000);
                //    }
                //});

            }
        });

    }
}
