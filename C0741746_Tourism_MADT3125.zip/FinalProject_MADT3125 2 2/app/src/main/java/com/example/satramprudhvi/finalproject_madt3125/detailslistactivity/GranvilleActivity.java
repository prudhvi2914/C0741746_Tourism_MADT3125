package com.example.satramprudhvi.finalproject_madt3125.detailslistactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.satramprudhvi.finalproject_madt3125.R;

public class GranvilleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_granville);
    }
}
