package com.example.satramprudhvi.finalproject_madt3125;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.satramprudhvi.finalproject_madt3125.Adapters.PlacesAdapter;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.ArtGalleryActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.Banff;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.Casaloma;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.CityHallActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.CnTowerActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.EatonActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.GlacierActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.MorineActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.MusemActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.RogersActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.StcActivity;
import com.example.satramprudhvi.finalproject_madt3125.detailslistactivity.Zoo;
import com.example.satramprudhvi.finalproject_madt3125.models.Place;

import java.util.ArrayList;

public class PlacesListActivity extends AppCompatActivity {
    private ListView lstplaces;
    private ArrayList<Place> placeslist;
    private PlacesAdapter placesAdapter;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_list);
        dbHelper = new DBHelper(this);



        lstplaces = findViewById(R.id.lstplaces);

      placeslist = Place.getPlaces();

//
        placesAdapter = new PlacesAdapter(this, placeslist);
        lstplaces.setAdapter(placesAdapter);
         lstplaces.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                  if(position==0){
                  Intent intent = new Intent(PlacesListActivity.this,Zoo.class) ;
                   startActivity(intent);
                   }
                 if(position==1){
                     Intent intent = new Intent(PlacesListActivity.this,Casaloma.class) ;
                     startActivity(intent);
                 }
                 if(position==2){

                     Intent intent = new Intent(PlacesListActivity.this,ArtGalleryActivity.class) ;
                     startActivity(intent);
                 }

                 if(position==3){
                     Intent intent = new Intent(PlacesListActivity.this,CnTowerActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==4){
                     Intent intent = new Intent(PlacesListActivity.this,EatonActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==5){
                     Intent intent = new Intent(PlacesListActivity.this,GlacierActivity.class) ;
                     startActivity(intent);
                 }
                 if(position==6){
                     Intent intent = new Intent(PlacesListActivity.this,Banff.class) ;
                     startActivity(intent);

                 }

                 if(position==7){
                     Intent intent = new Intent(PlacesListActivity.this,CityHallActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==8){
                     Intent intent = new Intent(PlacesListActivity.this,StcActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==9){
                     Intent intent = new Intent(PlacesListActivity.this,RogersActivity.class) ;
                     startActivity(intent);


                 }
                 if(position==10){
                     Intent intent = new Intent(PlacesListActivity.this,MorineActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==11){
                     Intent intent = new Intent(PlacesListActivity.this,MusemActivity.class) ;
                     startActivity(intent);

                 }
                 if(position==12){
                     Intent intent = new Intent(PlacesListActivity.this,MusemActivity.class) ;
                     startActivity(intent);

                 }


             }
         });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        return true;
    }
}
