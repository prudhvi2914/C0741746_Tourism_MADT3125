package com.example.satramprudhvi.finalproject_madt3125;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RankedPlacesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranked_places);
    }
}
